﻿using CommunityToolkit.Mvvm.ComponentModel;
using FileProcessor.Desktop.Helpers;
using FileProcessor.Mediator;
using FileProcessor.Mediator.Models;
using System.Collections.ObjectModel;
using System.Data;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace FileProcessor.Desktop.ViewModels
{
    public partial class SlotViewModel : ObservableObject
    {
        private readonly DataCoordinator _coordinator;
        private readonly int _index;

        public SlotViewModel(DataCoordinator coordinator, int index)
        {
            _coordinator = coordinator;
            _index = index;

            // 订阅协调器数据变更事件
            _coordinator.SlotDataChanged += (idx, data) => {
                if (idx == _index)
                {
                    // 核心：转发到 UI 线程更新 DataTable
                    System.Windows.Application.Current.Dispatcher.Invoke(() => {
                        DisplayTable = data?.ToDataTable();
                        Status = data != null ? SlotStatus.Ready : SlotStatus.NoData;
                    });
                }
            };
        }

        [ObservableProperty] private string? _selectedFile;
        [ObservableProperty] private string? _selectedBlock;
        [ObservableProperty] private DataTable? _displayTable;
        [ObservableProperty] private SlotStatus _status = SlotStatus.Empty;

        public ObservableCollection<string> AvailableFiles { get; } = new();
        public ObservableCollection<string> AvailableBlocks { get; } = new();

        public void RefreshFileList()
        {
            var files = _coordinator.GetAvailableFiles();
            AvailableFiles.Clear();
            foreach (var f in files) AvailableFiles.Add(f);
        }

        partial void OnSelectedFileChanged(string? value)
        {
            AvailableBlocks.Clear();
            if (string.IsNullOrEmpty(value)) return;
            foreach (var b in _coordinator.GetBlocksForFile(value)) AvailableBlocks.Add(b);
        }

        partial void OnSelectedBlockChanged(string? value)
        {
            // value 是用户选中的中文名，例如 "工况20 X方向..."
            if (!string.IsNullOrEmpty(SelectedFile) && !string.IsNullOrEmpty(value))
            {
                // 1. [核心修复] 反查标准 ID
                // 去问 Coordinator：在这个文件里，在这个版本下，这个中文名对应的原始 ID 是啥？
                var candidates = _coordinator.GetBlocksForFile(SelectedFile);
                // 注意：GetBlocksForFile 只返回了 string。我们需要更详细的信息。

                // 建议：直接调用 SnapshotManager 的查询接口（通过 Coordinator 暴露的）
                // 或者，我们修改 Coordinator.ConfigureSlot 让它智能一点，或者在这里查。

                // 最稳妥的写法（利用现有接口）：
                // 我们需要 Coordinator 提供一个方法：GetStandardName(fileName, displayName)
                // 如果没有，我们就在这里“笨”办法查一下：

                // 假设 Coordinator 有个方法能拿到 ProcessedResult 列表
                // 如果没有，建议在 DataCoordinator 加一个：
                // public IEnumerable<ProcessedResult> GetFullResultsForFile(string fileName) 
                // { return _snapshotManager.GetResultsByFile(ActiveViewVersionId, fileName); }

                // 既然我们现在不想改 Coordinator 接口，我们可以利用 AvailableBlocks 的对应关系
                // 但最简单的还是去 DataCoordinator 加这个查找逻辑。

                _coordinator.ConfigureSlot(_index, SelectedFile, value);
            }
        }
    }
}