﻿using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using FileProcessor.Desktop.ViewModels;
using FileProcessor.Infrastructure.Services;
using FileProcessor.Mediator;
using System.Collections.ObjectModel;
using System.Windows;

namespace FileProcessor.Desktop.ViewModels
{
    public partial class MainViewModel : ObservableObject
    {
        private readonly DataCoordinator _coordinator;
        private readonly ProjectMonitorService _monitor;

        public MainViewModel(DataCoordinator coordinator, ProjectMonitorService monitor)
        {
            _coordinator = coordinator;
            _monitor = monitor;

            // 初始化 8 个插槽
            for (int i = 0; i < 8; i++)
                Slots.Add(new SlotViewModel(_coordinator, i));

            StatusText = "就绪。请选择项目目录...";
            StatusColor = "#9E9E9E";
        }

        public ObservableCollection<SlotViewModel> Slots { get; } = new();
        public ObservableCollection<string> VersionHistory { get; } = new();

        [ObservableProperty] private string? _projectPath;
        [ObservableProperty] private string? _selectedVersion;
        [ObservableProperty] private string _currentTower = "All";
        [ObservableProperty] private string _statusText = "";
        [ObservableProperty] private string _statusColor = "";

        [RelayCommand]
        private void SelectProject()
        {
            using var dialog = new System.Windows.Forms.FolderBrowserDialog();
            if (dialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                ProjectPath = dialog.SelectedPath;
                StartProjectMonitoring(dialog.SelectedPath);
            }
        }

        private async void StartProjectMonitoring(string path)
        {
            try
            {
                StatusText = "正在初始化引擎...";

                // 1. 启动核心监控 (同步执行 InitialScan)
                // 注意：如果你把 StartScanning 改回了 Task.Run，这里记得 await
                _monitor.StartScanning(path);

                // 2. [核心修复] 自动搜寻最新的 Live 版本
                // 控制台里的逻辑搬过来：去 Snapshot 里找最近的一个 Live_ 开头的版本
                string? autoDetectedVersion = null;

                // 简单的重试机制，防止扫描太快还没存入
                for (int i = 0; i < 5; i++)
                {
                    // 利用 Coordinator 暴露的方法或直接通过 SnapshotManager 查
                    // 这里假设我们通过 Coordinator 间接查，或者你有办法访问 SnapshotManager
                    // 为了方便，我们通过 GetAvailableFiles 探测：如果能拿到文件，说明版本对了

                    // 更好的方式：我们在 DataCoordinator 加一个 GetLatestLiveVersion()，或者在这里硬编码查找
                    // 这里演示最通用的“盲猜”逻辑，或者你可以给 DataCoordinator 加一个属性

                    // 临时方案：直接利用 VersionCoordinator 的当前状态（如果它被 InitialScan 更新了）
                    // 但根据控制台日志，最稳的是去 Snapshot 里找
                    // 我们这里模拟“切换到 LIVE 状态”的动作：

                    VersionHistory.Clear();
                    VersionHistory.Add("LIVE 实时状态");

                    // 强制触发一次版本切换，让 Coordinator 内部去对齐
                    SelectedVersion = "LIVE 实时状态";

                    // 检查是否生效
                    if (_coordinator.GetAvailableFiles().Any())
                    {
                        StatusText = "数据已就绪";
                        break;
                    }

                    await Task.Delay(500); // 等待 0.5 秒重试
                }

                // 3. 刷新所有插槽的文件列表
                foreach (var slot in Slots)
                {
                    slot.RefreshFileList();
                }

                StatusText = $"监控运行中: {System.IO.Path.GetFileName(path)}";
                StatusColor = "#2ECC71";
            }
            catch (Exception ex)
            {
                System.Windows.MessageBox.Show("启动监控失败: " + ex.Message);
            }
        }

        partial void OnSelectedVersionChanged(string? value)
        {
            if (string.IsNullOrEmpty(value)) return;
            _coordinator.SwitchViewVersion(value);
            foreach (var slot in Slots) slot.RefreshFileList();
        }

        partial void OnCurrentTowerChanged(string value)
        {
            for (int i = 0; i < Slots.Count; i++)
                _coordinator.SetTowerFilter(i, value);
        }
    }
}